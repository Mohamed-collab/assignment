# customer.py
class Customer:
    def __init__(self, name, contact_info, loyalty_member=False):
        self._name = name
        self._contact_info = contact_info
        self._loyalty_member = loyalty_member

    def is_loyalty_member(self):
        return self._loyalty_member

    def __str__(self):
        return f"Customer(name={self._name}, loyalty_member={self._loyalty_member})"

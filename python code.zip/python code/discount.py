# discount.py
class Discount:
    LOYALTY_DISCOUNT = 0.10
    BULK_DISCOUNT = 0.20
    BULK_THRESHOLD = 5

    def apply_discount(self, total, loyalty_member=False, item_count=0):
        discount = 0
        if loyalty_member:
            discount += total * self.LOYALTY_DISCOUNT
        if item_count >= self.BULK_THRESHOLD:
            discount += total * self.BULK_DISCOUNT
        return total - discount

# order.py
from discount import Discount
from shopping_cart import ShoppingCart

class Order:
    VAT_RATE = 0.08

    def __init__(self, customer, cart):
        self._customer = customer
        self._cart = cart
        self._discount_handler = Discount()

    def calculate_total_with_discount_and_vat(self):
        item_count = len(self._cart._items)
        subtotal = self._cart.calculate_total()
        discounted_total = self._discount_handler.apply_discount(
            subtotal,
            loyalty_member=self._customer.is_loyalty_member(),
            item_count=item_count
        )
        return discounted_total + (discounted_total * self.VAT_RATE)

    def generate_invoice(self):
        total = self.calculate_total_with_discount_and_vat()
        return f"Invoice for {self._customer._name}: Total amount after discounts and VAT is {total:.2f}"

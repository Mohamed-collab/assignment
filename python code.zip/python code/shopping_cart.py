# shopping_cart.py
from ebook import Ebook

class ShoppingCart:
    def __init__(self):
        self._items = []

    def add_item(self, ebook):
        if isinstance(ebook, Ebook):
            self._items.append(ebook)

    def remove_item(self, ebook):
        if ebook in self._items:
            self._items.remove(ebook)

    def calculate_total(self):
        return sum(item.get_price() for item in self._items)

    def __str__(self):
        return f"ShoppingCart(items={[str(item) for item in self._items]})"

# test_cases.py
from ebook import Ebook
from customer import Customer
from shopping_cart import ShoppingCart
from order import Order

# Initialize instances
cart = ShoppingCart()
customer = None

# Sample e-books for the store's catalog
catalog = [
    Ebook("Book One", "Author A", "2021-01-01", "Fiction", 10.0),
    Ebook("Book Two", "Author B", "2021-01-02", "Non-Fiction", 15.0),
    Ebook("Book Three", "Author C", "2022-03-15", "Science", 20.0)
]

def display_catalog():
    print("\nAvailable E-books:")
    for i, ebook in enumerate(catalog, start=1):
        print(f"{i}. {ebook}")

def add_ebook_to_cart():
    display_catalog()
    choice = int(input("\nEnter the number of the e-book to add to the cart: ")) - 1
    if 0 <= choice < len(catalog):
        cart.add_item(catalog[choice])
        print(f"{catalog[choice]._title} added to cart.")
    else:
        print("Invalid choice.")

def remove_ebook_from_cart():
    print("\nE-books in Cart:")
    for i, ebook in enumerate(cart._items, start=1):
        print(f"{i}. {ebook}")
    choice = int(input("\nEnter the number of the e-book to remove from the cart: ")) - 1
    if 0 <= choice < len(cart._items):
        removed_ebook = cart._items[choice]
        cart.remove_item(removed_ebook)
        print(f"{removed_ebook._title} removed from cart.")
    else:
        print("Invalid choice.")

def create_customer_account():
    global customer
    name = input("Enter customer name: ")
    contact_info = input("Enter contact info (email or phone): ")
    loyalty = input("Is the customer a loyalty member? (y/n): ").lower() == 'y'
    customer = Customer(name, contact_info, loyalty_member=loyalty)
    print(f"Customer account created for {name}.")

def generate_invoice():
    if not customer:
        print("Please create a customer account first.")
    elif not cart._items:
        print("The cart is empty. Add e-books to the cart before generating an invoice.")
    else:
        order = Order(customer, cart)
        print("\n" + order.generate_invoice())

def main():
    while True:
        print("\n--- E-Bookstore Management System ---")
        print("1. View Catalog and Add E-book to Cart")
        print("2. Remove E-book from Cart")
        print("3. Create Customer Account")
        print("4. Generate Invoice")
        print("5. View Cart")
        print("6. Exit")
        
        choice = input("Choose an option: ")

        if choice == '1':
            add_ebook_to_cart()
        elif choice == '2':
            remove_ebook_from_cart()
        elif choice == '3':
            create_customer_account()
        elif choice == '4':
            generate_invoice()
        elif choice == '5':
            print("\nShopping Cart:", cart)
        elif choice == '6':
            print("Exiting the system.")
            break
        else:
            print("Invalid option. Please try again.")

if __name__ == "__main__":
    main()
